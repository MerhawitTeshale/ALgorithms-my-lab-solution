package question3;

public class Merge {
	
	public static int [] merge(int []arr1, int [] arr2)
	{
		int n=arr1.length+arr2.length;
		int []mergeNumber = new int [n];
		
		int i=0,j=0,k=0;
	
		while(i<arr1.length && j<arr2.length)
		{
			if (arr1[i]<=arr2[j])
			{
				mergeNumber[k]=arr1[i];
				i++;
			}
		else {
				mergeNumber[k]=arr2[j];
				j++;
			}
			k++;
		}
		
		while (i<arr1.length)
		{
			mergeNumber[k]=arr1[i];
			i++;
			k++;
		}
		while (j<arr2.length)
		{
			mergeNumber[k]=arr2[j];
			j++;
			k++;
		}
			return mergeNumber;
	}

	public static void main(String[] args) {
		
		int [] array1 = {1, 4, 5, 8, 17};
		int [] array2 = {2, 4, 8, 11, 13,  17, 21, 23, 25};
		int[] result= merge(array1, array2);
		
		for (int i=0; i<result.length;i++)
		{
			System.out.print(result[i]+" ");
		}
	}

}
