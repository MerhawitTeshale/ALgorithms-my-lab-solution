package question3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RemoveDupsEnhanced {

	
	public static HashMap<Integer,Integer> removeDups(List<Integer> list)
	{
		HashMap<Integer,Integer> M= new HashMap<>();
		 
			for (int i=0;i<list.size();i++)
			{
				if (!M.containsKey(list.get(i)))
				{
					M.put(list.get(i), 1);
				}
			}
		
		return M;
	}
	public static void main(String[] args) {
		
		List<Integer> numList= new ArrayList<>();
		numList.add(10);
		numList.add(10);
		numList.add(3);
		numList.add(3);
		numList.add(8);
		numList.add(8);

		Map<Integer,Integer> newList= removeDups(numList);
		System.out.println(newList);
	}

}
