package labOne;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Q6 {

	public static <T> List<Set<T>> powerSet(List<T> X) {
	    List<Set<T>> P = new ArrayList();
	    Set<T> S = new HashSet();
	    P.add(S);
	    if (X.isEmpty()) {
	        return P;
	    } else {
	        while(!X.isEmpty()) {
	            T f = X.remove(0);
	            List<Set<T>> temp = new ArrayList();
	            Iterator var6 = P.iterator();
	            Set x;
	            while(var6.hasNext()) {
	                x = (Set)var6.next();
	                temp.add(x);
	            }
	            var6 = temp.iterator();
	            while(var6.hasNext()) {
	                x = (Set)var6.next();
	                S = new HashSet();
	                S.add(f);
	                S.addAll(x);
	                P.add(S);
	            }
	        }
	        return P;
	    }

	}
	public static void main(String[] args) {
		List<Integer> num= new ArrayList<>();
		
		num.add(1);
		num.add(2);
		num.add(3);
		
		System.out.println(powerSet(num));
	}
}
