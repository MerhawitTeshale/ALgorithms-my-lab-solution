package labOne;

public class Question7 {

	public static int generate(int n){
		if(n == 0) return 0;
		if(n == 1) return 1;
		
		 
		int res = 0;
		res+=generate(n-1)+ generate(n-2);
		
	 return res;
	}

	public static void main(String[] args) {

		//0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765.
		for (int i=0;i<=20;i++)
		{
			System.out.print(generate(i)+", ");
		}

	}

}
