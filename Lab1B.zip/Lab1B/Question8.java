package labOne;

public class Question8 {

	
	public static int smallestCommon(int x, int y) {
		
		if (x==0||y==0) return 0;
		
		int absNumber1=Math.abs(x);
		int absNumber2=Math.abs(y);
		
		int max=absNumber1>absNumber2?absNumber1:absNumber2;
		int comonFactro= max;
		int min=absNumber1>absNumber2?absNumber2:absNumber1;
		
		
		while (comonFactro % min !=0)
		{
			comonFactro+=max;
		}
		
		return comonFactro;
		}

	public static void main(String[] args) {
		System.out.println(smallestCommon(4, 6));
		System.out.println(smallestCommon(3, 5));
		System.out.println(smallestCommon(7, 14));

	}

}
