package labOne;

public class Question1 {
	
	/**
	 * this is looking for any elements in an array that sum up to the given value z
	 * to do this what i did is 
	 * 
	 * i took the first element and sum it to with the next element in the array which has distinct value and 
	 * compare the sum with z 
	 * if true my code returns true 
	 * and if not it will continue to the next elements until array length is reached.
	 * 
	 * if still no match is found then i move to the next element and do the whole process again.
	 * 
	 * if my outer loop reached array length with out finding match then it will return false.
	 * 
	 * this has O(n^2) running time and may be could be done more efficiently but i couldn't think of any other method 
	 * 
	 * @param arr
	 * @param z
	 * @return
	 */
	
	public static boolean sumFound(int[] arr, int z) {
		if(arr==null || arr.length < 2) {
		return false;
		}
		int sum =0;
		
		for (int i=1; i<arr.length;i++)
		{
			for (int j=0;j<arr.length;j++)
			{
				
			if(arr[i]!=arr[j])
				sum= arr[i]+arr[j];
			
			if (sum==z) return true;
			
			}
		}
			return false;
		}


	public static void main(String [] args)
	{
		int arr[]= {1, 4, 2, 3};
		int arr2 []= {3, 3, 4, 7};
		int arr3[]= {1};
		
		// expected result is true false false
		System.out.println(sumFound(arr,5));
		System.out.println(sumFound(arr2,6));
		System.out.println(sumFound(arr3,2));
	}
}
