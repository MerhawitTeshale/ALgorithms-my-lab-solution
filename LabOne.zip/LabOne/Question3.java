package labOne;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import lab1.powerset.PowerSet;
 
/**
 * this has nested loop which might not be ideal because to find the subsets it self it is O(2^n) time at minimum and 
 * making it n^22^n is the worst but this is the only way i was able to solve this problem.
 *  
 * @author Merry
 * 
 */
public class Question3 {

	// will be back after solving question 6
	public static boolean sumFound(List list, int k) {
		
		if (list==null)
			throw new  IllegalArgumentException("List has no element");
		
		List<Set<Integer>> mySet = PowerSet.powerSet(list);
		//System.out.println(mySet);
		//int sum = 0;
		for (Set<Integer> s : mySet) {
			int sum = 0;
			for (int value: s) {
				sum += value;
			}
			if (sum == k)
				return true;
		}
		return false;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list = new ArrayList() {
			{
				add(1);
				add(2);
				add(3);
			}
		};
		
		//expected out put is false 
		System.out.println(sumFound(list,8));
	}

}
