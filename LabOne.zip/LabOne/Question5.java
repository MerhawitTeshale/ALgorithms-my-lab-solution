package labOne;

public class Question5 {
	
	/**
	 * @author Merry
	 * 
	 *
		yes i believe there is a better solution if the array is sorted, this is taking the given z and comparing it to the 
		middle element of the array
		
		assume we have array sorted in an ascending order and that has middle element 
		
			if array has size <2 just look for z 
			for anything greater than this 
			
		  		1. if z==middle element 
		  		2. if z>middle element and then continue your search to the right half of the array
		  		3. if z<middle element the search on the left half of the array
		  		
		  		because we keep dividing the array in to two the running time will be (clog n base 2) and this is better that the one 
		  		we have here which has n running time 
	 */

	/**
	 * 
	 * @param arr
	 * @param z
	 * @return
	 * 
	 * this will return true if z exists in arr ranging from 0 to n
	 * returns false if array is empty 
	 * 
	 * this will have running time of O(n) i believe this is efficent 
	 */
	public static boolean find(int[] arr, int z) {
		
		if (arr.length==0) return false;
		for (int i=0;i<arr.length;i++)
		{
			if (arr[i]==z) return true;
		}
		return false;
		}
	
	/**
	 * this is to show how we can search for an element in a sorted list 
	 * @param arr
	 * @param z
	 * @return
	 */
	public static boolean findIfSorted(int[] arr, int z, int start, int end) {
		
		//base case
		if (end < start) 
			return false;
		
		int mid= (start+end)/2;
		
		
		if (arr[mid]==z) return true;
		
		if (arr[mid]<z)
		{
			return findIfSorted(arr, z, (mid+1), end);
		}
		
			return findIfSorted(arr, z,start,(mid-1));
		}
	
	public static void main(String[] args) {
		
		int arr[]= {2, 8, 3, 4};
		int arr1[]= {2, 3, 4, 8};
		// expected out put is true false true false
		System.out.println(find(arr,3));
		System.out.println(find(arr,5));
		System.out.println(find(arr1,3));
		System.out.println(find(arr1,5));
		
		int arr2[]= {1,2,3,4,5};
		int n=arr2.length-1;
		System.out.println(findIfSorted(arr2,1,0,n));
		
	}

}
