package labOne;

public class Question2 {
	
	/**
	 * i believe this is efficient solution to this problem because it involves only one loop that goes through all the inputs
	 * this can be done in less efficient way with nested loop and the running time will be O(n^2) 
	 * but my algorithm runs at O(n) time
	 * @param arr
	 * @return
	 */

	public static int secondSmallest(int[] arr) {
		if (arr == null || arr.length < 2) {
			throw new IllegalArgumentException("Input array too small");
		}
		// implement

		int small = arr[0];
		int secSmall = arr[1];
		int temp;

		if (arr[0] > arr[1]) {
			small = arr[1];
			secSmall = arr[0];
		}
		for (int i = 2; i < arr.length; i++) {
			if (small > arr[i]) {
				temp = small;
				small = arr[i];
				secSmall = temp;
			}

			else if (secSmall > arr[i]) {
				secSmall = arr[i];
			}

		}
		return secSmall;
	}

	public static void main(String[] args) {
				
		int arr[]= {1, 4, 2, 3};
		int arr1[]= {4,7, 3, 3};
		int arr2[]= {9};
		
		// expected out put is 2 3 and exception
		System.out.println(secondSmallest(arr));
		System.out.println(secondSmallest(arr1));
		System.out.println(secondSmallest(arr2));
		
	}
}
