package labOne;

import java.util.ArrayList;

import java.util.LinkedList;

/**
 * 
 * @author Merry
 * 
 * this is not the best way to sort because we are looping 
 * to n twice and this is gone result in O(n^2) running time 
 * which is large as n->infinity
 * 
 * but i feel like this is the best way we can sort inplace 
 *
 */

public class Question4 {
	
	
	//sorting 
	
	public static void sort(ArrayList<Integer> list){
		
		int index=list.size();
		int swap;
		
		for (int i=1;i<index;i++)
		{
			for (int j=0; j<index-1;j++)
			{
				if (list.get(j)>list.get(j+1))
				{
					swap=list.get(j);
					list.set(j, list.get(j+1));
					list.set(j+1, swap);
				}
			}
		}
		
		}
	
	/**
	 * although the approach i used to solve the two problems appear to be the same 
	 * internally they are not.
	 * 
	 * Because in linkedList accessing the ith position is expensive 
	 * we always start from head and go all the way to i.
	 * 
	 * in array list accessing the ith position is O(1) time 
	 * but in linkedList  accessing ith element takes O(n) time now with my algorithms
	 * O(n^2) time it will be O(n^3) 
	 * 
	 * @param list
	 */
	
	public static void sort(LinkedList<Integer> list){
		int index =list.size();
		int swap;
		for (int i=1;i<index;i++)
		{
			for (int j=0; j<index-1;j++)
			{
				if (list.get(j)>list.get(j+1))
				{
					swap=list.get(j);
					list.set(j, list.get(j+1));
					list.set(j+1, swap);
				}
			}
		}
		
		}

	public static void main(String [] args)
	{
		ArrayList <Integer>list1= new ArrayList<>();
		list1.add(3);
		list1.add(5);
		list1.add(1);
		list1.add(7);
		list1.add(4);
		list1.add(9);
		sort(list1); 
		
		//expected out put is - 1,3,4,5,7,9
		System.out.println(list1);
		
		LinkedList<Integer> list = new LinkedList<>();
		list.add(3);
		list.add(5);
		list.add(1);
		list.add(7);
		list.add(4);
		list.add(9);
		sort(list);
		
		//expected out put is - 1,3,4,5,7,9
		System.out.println(list);
	}
}
